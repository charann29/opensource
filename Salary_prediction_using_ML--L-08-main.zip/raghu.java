.int x = 5;
int y = 6;
int sum = x + y;
System.out.println(sum); // Print the sum of x + y
